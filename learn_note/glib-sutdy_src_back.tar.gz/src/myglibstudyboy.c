/*
 * myglibstudyboy.c
 *
 *  Created on: 2016-6-3
 *      Author: sns
 */

#include <glib.h>
#include <glib-object.h>
#include "myglibstudyboy.h"


//向GObject系统注册这个类【就是注册有这么一个类型】
GType jc_boy_get_type(void)
{
	static GType JcBoy_type = 0;
	if(!JcBoy_type)
		{
			static const GTypeInfo boy_info = {
					sizeof(JcBoyClass),
					NULL,NULL,
					(GClassInitFunc)jc_boy_class_init,
					NULL,NULL,
					sizeof(JcBoy),
					0,
					(GInstanceInitFunc)jc_boy_init
		};
			JcBoy_type = g_type_register_static(G_TYPE_OBJECT,"JcBoy",&boy_info,0);
//			g_type_register_static_simple();
//			JcBoy_type = G_DEFINE_TYPE (JcBoy ,Jc_Boy,G_TYPE_OBJECT) ;
		}
	return JcBoy_type;
}


static void jc_boy_init (JcBoy *self)
{
	JcBoyPrivate *priv=NULL;
	priv=self->priv = JC_BOY_GET_PRIVATE (self); 		//它调用的是g_type_instance_get_private，获取了一个指向实例私有结构体的一个指针
	priv->name=g_strdup("no-name");
	priv->hobby=g_strdup("nothing");
	priv->age=0;
}

static void jc_boy_class_init (JcBoyClass *klass)
{
    g_type_class_add_private (klass, sizeof (JcBoyPrivate));	//将实例中的私有结构在类结构中声明下
    klass->play=play;
    //----------------------------------------
    //显示声明下曝光和终结用的函式???????????
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);
    gobject_class->dispose=jc_boy_dispose;
    gobject_class->finalize=jc_boy_finalize;
    //----------------------------------------
}


void play()
{
	g_print("the boy is playing football !\n");
}

//G_DEFINE_TYPE (JcBoy ， jc_boy ， G_TYPE_OBJECT) ;

void jc_boy_change_hobby(JcBoy *self,gchar *hobby)
{
	JcBoyPrivate *priv;
	self->priv = priv = JC_BOY_GET_PRIVATE(self);	//JC_BOY_GET_PRIVATE获取了一个指向实例私有结构体的一个指针
	g_free (priv->hobby);
	priv->hobby=g_strdup("playing basketball");
	g_print("recently the boy is interested in %s\n",hobby);
}

static void jc_boy_dispose (GObject *gobject)
{
	  JcBoy *self = JC_BOY (gobject);
	  /*
	   * In dispose, you are supposed to free all types referenced from this
	   * object which might themselves hold a reference to self. Generally,
	   * the most simple solution is to unref all members on which you own a
	   * reference.
	   */
	  /* dispose might be called multiple times, so we must guard against
	   * calling g_object_unref() on an invalid GObject.
	   */
	  // if (self->priv->an_object)
	  //  {
	  //   g_object_unref (self->priv->an_object);
	  //   self->priv->an_object = NULL;
	  // }
	  /* Chain up to the parent class */
//  	  G_OBJECT_CLASS (jc_boy_parent_class)->dispose (gobject);
}

static void jc_boy_finalize(GObject *gobject)
{
	JcBoy *self =JC_BOY (gobject);
	g_free (self->priv->hobby);
	g_free (self->priv->name);
	g_print("boy finalized !\n");
	/* Chain up to the parent class */
//	G_OBJECT_CLASS (jc_boy_parent_class)->finalize (gobject);
}

