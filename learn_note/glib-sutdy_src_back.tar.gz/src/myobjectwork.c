/*
 ============================================================================
 Name        : myobjectwork.c
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include <stdio.h>
#include<stdlib.h>
#include <glib.h>
#include "myboy.h"
#include "myman.h"
#include "myglibstudyboy.h"

#include <glib/gmacros.h>
typedef struct _MyStruct MyStruct;

struct _MyStruct
{
	int oneintdate;
	char onechardate;
	int *towintdate;
	char *towchardate;
};
char Mychar[10];

int main(int argc,char *argv[])
{
	g_type_init();
	Boy *tom,*peter;
	Man *green,*brown;

	tom = boy_new_with_name("Tom");
	tom->cry();
	g_print("\n========The boy of tom info is :========\n");
	boy_info(tom);
	peter = boy_new_with_name_and_age("Peter",10);
	peter->cry();
	g_print("\n========The boy of peter info is :========\n");
	boy_info(peter);

	green = man_new();
//	GObject *aaa = (GObject *)green;
//	printf("ref_count=========00============%d\n",aaa->ref_count);
//	g_object_ref(aaa);
//	printf("ref_count=========11============%d\n",aaa->ref_count);
//	g_object_unref(green);
//	printf("unref_count=======22============%d\n",aaa->ref_count);
	boy_set_name(BOY(green),"Green");
	//====================================
	boy_set_age(BOY(green),28);
	man_set_job(green,"Doctor");
	green->bye();
	g_print("\n========The boy of green info is :========\n");
	man_info(green);

	brown = man_new_with_name_age_and_job("Brown",30,"Teacher");
	brown->bye();
	g_print("\n========The boy of brown info is :========\n");
	man_info(brown);


	MyStruct *test = NULL;
	test=g_slice_new(MyStruct);
	/*调用test*/
	if(test)
	{
		g_slice_free(MyStruct,test);
		test = NULL;
	}

//	g_object_unref(green);
}

