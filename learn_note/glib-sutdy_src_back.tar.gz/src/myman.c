/*
 * myman.c
 *
 *  Created on: 2016-5-26
 *      Author: sns
 */

/*man.c*/
#include "myman.h"

static void man_bye(void);
static void man_init(Man *man);
static void man_class_init(ManClass *manClass);
static void	   finalize_od (GObject *object);
static void	   dispose_od (GObject *object);

GType man_get_type(void)
{
	static GType man_type = 0;
	if(!man_type)
	{
		static const GTypeInfo man_info = {
		sizeof(ManClass),
		NULL,NULL,
		(GClassInitFunc)man_class_init,
		NULL,NULL,
		sizeof(Man),
		0,
		(GInstanceInitFunc)man_init
		};
		g_print("\n========The test fun [[man_get_type]] is 2 :========\n");
		man_type = g_type_register_static(BOY_TYPE,"Man",&man_info,0);
	}
	return man_type;
}

static void man_init(Man *man)
{
	man->jod = g_strdup("none");
	man->bye = man_bye;
}

static void man_class_init(ManClass *manClass)
{
	GObjectClass   *gobject_class = (GObjectClass *) manClass;
     gobject_class->finalize = finalize_od;
     gobject_class->dispose = dispose_od;
	BoyClass *boyClass =(BoyClass *)manClass;
}

static void	   finalize_od (GObject *object)
{
	Man *man = (Man *)object;
	printf("man finalize_od\n");
	if(man->job){
		g_free(man->job);
		man->job = NULL;
	}
	//	G_OBJECT_CLASS (man_parent_class)->finalize (object);
}

static void	   dispose_od (GObject *object)
{
	printf("man dispose_od\n");
	//	G_OBJECT_CLASS (man_parent_class)->dispose (object);
}

Man* man_new(void)
{
	Man *man;
	man = g_object_new(MAN_TYPE,NULL);
	return man;
}

gchar* man_get_job(Man *man)
{
	return man->job;
}

void man_set_job(Man *man,char *job)
{
	man->job = job;
}

Man* man_new_with_name_age_and_job(gchar *name,gint age,gchar *job)
{
	Man *man;
	man = man_new();
	boy_set_name(BOY(man),name);
	boy_set_age(BOY(man),age);
	man_set_job(man,job);
	return man;
}

static void man_bye(void)
{
	g_print("Goodbye everyon !\n");
}

man_info(Man *man)
{
	g_print("The Man name is %s \n",BOY(man)->name);
	g_print("The Man age is %d \n",BOY(man)->age);
	g_print("The man job is %s \n",man->job);
}

