/*
 * myglibstudyboy.h
 *
 *  Created on: 2016-6-3
 *      Author: sns
 */

#ifndef _MYGLIBSTUDYBOY_H_
#define _MYGLIBSTUDYBOY_H_

#include <glib-object.h>

struct _JcBoyPrivate
{
	gchar *name;
	guint age;
	gchar *hobby;
};


//获取类型
#define JC_TYPE_BOY    (jc_boy_get_type ())
//实例类型转换
#define JC_BOY(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), JC_TYPE_BOY, JcBoy))
//实例类型判定
#define JC_IS_BOY(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), JC_TYPE_BOY))
//类结构转换
#define JC_BOY_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), JC_TYPE_BOY, JcBoyClass))
//类结构判定
#define JC_IS_BOY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), JC_TYPE_BOY))
//获取类结构
#define JC_BOY_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), JC_TYPE_BOY, JcBoyClass))
//获取私有结构，如果没有可不定义该宏
#define JC_BOY_GET_PRIVATE(obj) (G_TYPE_INSTANCE_GET_PRIVATE ((obj), JC_TYPE_BOY, JcBoyPrivate))
//基本上都是 域_类名_***的结构，也就是JC_BOY_***,如果每次都自己写还是很麻烦的，所以用GObject基本上copy的次数会很多。
//实例类型转换时，要将一个继承自BOY的对象man转换成BOY就可以使用JC_BOY(man)。

typedef struct _JcBoyPrivate JcBoyPrivate;
typedef struct _JcBoy      JcBoy;
typedef struct _JcBoyClass   JcBoyClass;


static void jc_boy_dispose (GObject *gobject);
static void jc_boy_finalize(GObject *gobject);
static void jc_boy_init (JcBoy *self);
static void jc_boy_class_init (JcBoyClass *klass);
void play();
void jc_boy_change_hobby(JcBoy *self,gchar *hobby);

/* object */
struct _JcBoy
{
//    JcBaby parent_instance;
	GObject parent_instance;
    /* public */
    //
    /*< private >*/
    JcBoyPrivate *priv;
};

/* class */
struct _JcBoyClass
{
//    JcBabyClass parent_class;
	GObjectClass   parent_class;

    /* class members */
    //
    /* Virtual method or signals*/

    void (*play)(JcBoy *self);
};

#endif /*_MYGLIBSTUDYBOY_H_*/
