/*
 * myman.h
 *
 *  Created on: 2016-5-26
 *      Author: sns
 */

#ifndef __MYMAN_H__
#define __MYMAN_H__
/*myman.h*/

#include <glib-object.h>
#include "myboy.h"

G_BEGIN_DECLS

#define MAN_TYPE (man_get_type())
#define MAN(obj) (G_TYPE_CHECK_INSTANCE_CAST((obj),MAN_TYPE,Man))

typedef struct _Man Man;
typedef struct _ManClass ManClass;

struct _Man
{
	Boy parent;
	char *job;
	char *jod;
	void (*bye)(void);
};

struct _ManClass
{
	BoyClass parent_class;
	void (*cry_born)(void);
};
GType man_get_type(void);
Man* man_new(void);
gchar* man_get_job(Man *man);
void man_set_job(Man *man,gchar *jod);

Man* man_new_with_name_age_and_job(gchar *mane,gint age,gchar *job);
void man_iofo(Man *man);

#endif /*__MYMAN_H__*/
